#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"

if [ ! -d .venv ]; then
  python3 -m venv .venv
fi
source .venv/bin/activate

pip install --upgrade pip >/dev/null
pip install -r requirements.txt

mkdir -p data logs
exec python -m app.main
